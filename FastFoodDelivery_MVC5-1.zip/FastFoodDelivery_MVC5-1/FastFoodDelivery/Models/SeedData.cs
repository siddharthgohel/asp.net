using System;
using System.Data.Entity;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace FastFoodDelivery.Models
{
    public class SeedData : CreateDatabaseIfNotExists<ApplicationDbContext>
    {
        protected override void Seed(ApplicationDbContext db)
        {
            var pizza = new Category { Name = "Pizza" };
            var burger = new Category { Name = "Burger" };
            var fries = new Category { Name = "Sides" };
            var drink = new Category { Name = "Drinks" };
            db.Categories.AddRange(new[] { pizza, burger, fries, drink });

            db.FoodItems.AddRange(new[]
            {
                new FoodItem { Name="Margherita Pizza", Description="Classic cheese and tomato pizza.", Price=199, Category=pizza, ImageUrl="https://images.unsplash.com/photo-1574071318508-1cdbab80d002", IsAvailable=true },
                new FoodItem { Name="Farmhouse Pizza", Description="Loaded with fresh vegetables and cheese.", Price=299, Category=pizza, ImageUrl="https://images.unsplash.com/photo-1565299624946-b28f40a0ae38", IsAvailable=true },
                new FoodItem { Name="Classic Burger", Description="Juicy patty, lettuce, tomato and sauce.", Price=149, Category=burger, ImageUrl="https://images.unsplash.com/photo-1568901346375-23c9450c58cd", IsAvailable=true },
                new FoodItem { Name="Cheese Burger", Description="Classic burger with extra melted cheese.", Price=179, Category=burger, ImageUrl="https://images.unsplash.com/photo-1550547660-d9450f859349", IsAvailable=true },
                new FoodItem { Name="French Fries", Description="Crispy golden fries with seasoning.", Price=99, Category=fries, ImageUrl="https://images.unsplash.com/photo-1573080496219-bb080dd4f877", IsAvailable=true },
                new FoodItem { Name="Cold Coffee", Description="Chilled creamy coffee.", Price=119, Category=drink, ImageUrl="https://images.unsplash.com/photo-1461023058943-07fcbe16d735", IsAvailable=true }
            });

            db.Users.Add(new User
            {
                FullName = "Administrator",
                Email = "admin@fastfood.com",
                PasswordHash = Hash("Admin@123"),
                Phone = "9999999999",
                Address = "Fast Food HQ",
                Role = "Admin"
            });
            db.Users.Add(new User
            {
                FullName = "Demo Customer",
                Email = "customer@fastfood.com",
                PasswordHash = Hash("Customer@123"),
                Phone = "9999999999",
                Address = "Ahmedabad, Gujarat",
                Role = "Customer"
            });
            db.SaveChanges();
            base.Seed(db);
        }

        public static string Hash(string value)
        {
            using (var sha = SHA256.Create())
            {
                return Convert.ToBase64String(sha.ComputeHash(Encoding.UTF8.GetBytes(value)));
            }
        }
    }
}
