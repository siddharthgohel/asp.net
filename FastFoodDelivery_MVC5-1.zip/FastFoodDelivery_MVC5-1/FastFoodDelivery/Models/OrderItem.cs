using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FastFoodDelivery.Models
{
    public class OrderItem
    {
        [Key] public int OrderItemId { get; set; }
        public int OrderId { get; set; }
        public int FoodItemId { get; set; }
        [Required] public string FoodName { get; set; }
        public decimal UnitPrice { get; set; }
        public int Quantity { get; set; }
        public decimal LineTotal { get; set; }
        public virtual Order Order { get; set; }
        public virtual FoodItem FoodItem { get; set; }
    }
}
