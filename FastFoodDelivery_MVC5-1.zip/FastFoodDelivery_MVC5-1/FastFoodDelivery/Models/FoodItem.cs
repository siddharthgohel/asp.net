using System.ComponentModel.DataAnnotations;

namespace FastFoodDelivery.Models
{
    public class FoodItem
    {
        [Key] public int FoodItemId { get; set; }
        [Required, StringLength(120)] public string Name { get; set; }
        [StringLength(500)] public string Description { get; set; }
        [Range(1, 99999)] public decimal Price { get; set; }
        [StringLength(500)] public string ImageUrl { get; set; }
        public bool IsAvailable { get; set; } = true;
        public int CategoryId { get; set; }
        public virtual Category Category { get; set; }
    }
}
