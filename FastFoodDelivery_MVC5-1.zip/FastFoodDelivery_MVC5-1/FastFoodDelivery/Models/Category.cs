using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FastFoodDelivery.Models
{
    public class Category
    {
        [Key] public int CategoryId { get; set; }
        [Required, StringLength(80)] public string Name { get; set; }
        public virtual ICollection<FoodItem> FoodItems { get; set; } = new List<FoodItem>();
    }
}
