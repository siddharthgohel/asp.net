using System.Data.Entity;

namespace FastFoodDelivery.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext() : base("FastFoodDB") { }
        public DbSet<User> Users { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<FoodItem> FoodItems { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
    }
}
