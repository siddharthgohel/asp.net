using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FastFoodDelivery.Models
{
    public class User
    {
        [Key] public int UserId { get; set; }
        [Required, StringLength(100)] public string FullName { get; set; }
        [Required, EmailAddress, StringLength(150)] public string Email { get; set; }
        [Required] public string PasswordHash { get; set; }
        [StringLength(20)] public string Phone { get; set; }
        [StringLength(300)] public string Address { get; set; }
        [Required, StringLength(20)] public string Role { get; set; } = "Customer";
        public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
    }
}
