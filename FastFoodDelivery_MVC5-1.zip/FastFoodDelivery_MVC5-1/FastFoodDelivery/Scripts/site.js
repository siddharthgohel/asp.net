document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll(".alert").forEach(function(a){
    setTimeout(function(){ if(a && a.parentNode) a.parentNode.removeChild(a); }, 4500);
  });
});
