using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using FastFoodDelivery.Models;

namespace FastFoodDelivery.Controllers
{
    public class CartController : Controller
    {
        private readonly ApplicationDbContext db = new ApplicationDbContext();
        private const string CartKey = "FASTFOOD_CART";

        private List<CartItem> Cart
        {
            get { return Session[CartKey] as List<CartItem> ?? new List<CartItem>(); }
            set { Session[CartKey] = value; }
        }

        public ActionResult Index() { return View(Cart); }

        [HttpPost]
        public ActionResult Add(int id, int quantity = 1)
        {
            var food = db.FoodItems.Find(id);
            if (food == null || !food.IsAvailable) return HttpNotFound();
            var cart = Cart;
            var item = cart.FirstOrDefault(x => x.FoodItemId == id);
            if (item == null)
                cart.Add(new CartItem { FoodItemId=id, Name=food.Name, Price=food.Price, ImageUrl=food.ImageUrl, Quantity=quantity });
            else item.Quantity += quantity;
            Cart = cart;
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Update(int id, int quantity)
        {
            var cart = Cart;
            var item = cart.FirstOrDefault(x => x.FoodItemId == id);
            if (item != null) item.Quantity = quantity;
            Cart = cart.Where(x => x.Quantity > 0).ToList();
            return RedirectToAction("Index");
        }

        public ActionResult Remove(int id)
        {
            Cart = Cart.Where(x => x.FoodItemId != id).ToList();
            return RedirectToAction("Index");
        }
    }
}
