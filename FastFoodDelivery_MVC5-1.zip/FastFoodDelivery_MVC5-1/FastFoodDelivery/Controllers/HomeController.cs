using System.Linq;
using System.Web.Mvc;
using FastFoodDelivery.Models;

namespace FastFoodDelivery.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext db = new ApplicationDbContext();

        public ActionResult Index()
        {
            ViewBag.Featured = db.FoodItems.Where(x => x.IsAvailable).Take(6).ToList();
            return View();
        }

        public ActionResult About() { return View(); }
        public ActionResult Contact() { return View(); }
    }
}
