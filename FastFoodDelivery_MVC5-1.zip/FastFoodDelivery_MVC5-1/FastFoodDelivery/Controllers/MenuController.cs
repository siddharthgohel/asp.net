using System.Linq;
using System.Web.Mvc;
using FastFoodDelivery.Models;

namespace FastFoodDelivery.Controllers
{
    public class MenuController : Controller
    {
        private readonly ApplicationDbContext db = new ApplicationDbContext();

        public ActionResult Index(int? categoryId, string search)
        {
            var foods = db.FoodItems.Where(x => x.IsAvailable).AsQueryable();
            if (categoryId.HasValue) foods = foods.Where(x => x.CategoryId == categoryId.Value);
            if (!string.IsNullOrWhiteSpace(search))
                foods = foods.Where(x => x.Name.Contains(search) || x.Description.Contains(search));
            ViewBag.Categories = db.Categories.ToList();
            ViewBag.CategoryId = categoryId;
            ViewBag.Search = search;
            return View(foods.OrderBy(x => x.Name).ToList());
        }

        public ActionResult Details(int id)
        {
            var food = db.FoodItems.Find(id);
            if (food == null || !food.IsAvailable) return HttpNotFound();
            return View(food);
        }
    }
}
