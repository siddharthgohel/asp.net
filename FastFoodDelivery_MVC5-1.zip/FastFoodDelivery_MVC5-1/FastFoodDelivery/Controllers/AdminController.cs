using System.Linq;
using System.Web.Mvc;
using FastFoodDelivery.Models;

namespace FastFoodDelivery.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext db = new ApplicationDbContext();

        private bool IsAdmin() { return Session["Role"] != null && Session["Role"].ToString() == "Admin"; }

        private ActionResult Guard()
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Account");
            return null;
        }

        public ActionResult Dashboard()
        {
            var g = Guard(); if (g != null) return g;
            ViewBag.Users = db.Users.Count();
            ViewBag.Foods = db.FoodItems.Count();
            ViewBag.Orders = db.Orders.Count();
            ViewBag.Sales = db.Orders.Select(x => (decimal?)x.TotalAmount).Sum() ?? 0;
            return View();
        }

        public ActionResult Foods()
        {
            var g = Guard(); if (g != null) return g;
            return View(db.FoodItems.Include("Category").OrderByDescending(x => x.FoodItemId).ToList());
        }

        public ActionResult CreateFood()
        {
            var g = Guard(); if (g != null) return g;
            ViewBag.Categories = new SelectList(db.Categories, "CategoryId", "Name");
            return View();
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult CreateFood(FoodItem food)
        {
            var g = Guard(); if (g != null) return g;
            if (!ModelState.IsValid) {
                ViewBag.Categories = new SelectList(db.Categories, "CategoryId", "Name");
                return View(food);
            }
            db.FoodItems.Add(food); db.SaveChanges();
            return RedirectToAction("Foods");
        }

        public ActionResult EditFood(int id)
        {
            var g = Guard(); if (g != null) return g;
            var food = db.FoodItems.Find(id); if (food == null) return HttpNotFound();
            ViewBag.Categories = new SelectList(db.Categories, "CategoryId", "Name", food.CategoryId);
            return View(food);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult EditFood(FoodItem food)
        {
            var g = Guard(); if (g != null) return g;
            if (!ModelState.IsValid) {
                ViewBag.Categories = new SelectList(db.Categories, "CategoryId", "Name", food.CategoryId);
                return View(food);
            }
            db.Entry(food).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Foods");
        }

        public ActionResult DeleteFood(int id)
        {
            var g = Guard(); if (g != null) return g;
            var food = db.FoodItems.Find(id); if (food == null) return HttpNotFound();
            db.FoodItems.Remove(food); db.SaveChanges();
            return RedirectToAction("Foods");
        }

        public ActionResult Orders()
        {
            var g = Guard(); if (g != null) return g;
            return View(db.Orders.Include("User").OrderByDescending(x => x.OrderDate).ToList());
        }

        [HttpPost]
        public ActionResult UpdateStatus(int id, string status)
        {
            var g = Guard(); if (g != null) return g;
            var order = db.Orders.Find(id);
            if (order == null) return HttpNotFound();
            order.Status = status;
            db.SaveChanges();
            return RedirectToAction("Orders");
        }
    }
}
