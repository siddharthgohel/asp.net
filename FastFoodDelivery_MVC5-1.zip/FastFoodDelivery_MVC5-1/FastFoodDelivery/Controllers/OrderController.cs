using System;
using System.Linq;
using System.Web.Mvc;
using FastFoodDelivery.Models;

namespace FastFoodDelivery.Controllers
{
    public class OrderController : Controller
    {
        private readonly ApplicationDbContext db = new ApplicationDbContext();
        private int? CurrentUserId { get { return Session["UserId"] as int?; } }

        private bool LoggedIn() { return CurrentUserId.HasValue; }

        public ActionResult Checkout()
        {
            if (!LoggedIn()) return RedirectToAction("Login", "Account", new { returnUrl = Url.Action("Checkout") });
            var cart = Session["FASTFOOD_CART"] as System.Collections.Generic.List<CartItem>;
            if (cart == null || !cart.Any()) return RedirectToAction("Index", "Cart");
            var user = db.Users.Find(CurrentUserId.Value);
            ViewBag.User = user;
            return View(cart);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult PlaceOrder(string address)
        {
            if (!LoggedIn()) return RedirectToAction("Login", "Account");
            var cart = Session["FASTFOOD_CART"] as System.Collections.Generic.List<CartItem>;
            if (cart == null || !cart.Any()) return RedirectToAction("Index", "Cart");
            if (string.IsNullOrWhiteSpace(address)) {
                TempData["Error"] = "Delivery address is required.";
                return RedirectToAction("Checkout");
            }

            var order = new Order {
                UserId = CurrentUserId.Value,
                DeliveryAddress = address,
                Status = "Placed",
                OrderDate = DateTime.Now,
                TotalAmount = cart.Sum(x => x.Total)
            };
            db.Orders.Add(order);
            db.SaveChanges();

            foreach (var item in cart)
                db.OrderItems.Add(new OrderItem {
                    OrderId=order.OrderId, FoodItemId=item.FoodItemId, FoodName=item.Name,
                    UnitPrice=item.Price, Quantity=item.Quantity, LineTotal=item.Total
                });
            db.SaveChanges();
            Session["FASTFOOD_CART"] = null;
            return RedirectToAction("Success", new { id = order.OrderId });
        }

        public ActionResult Success(int id)
        {
            var order = db.Orders.Find(id);
            if (order == null || !LoggedIn() || order.UserId != CurrentUserId.Value) return HttpNotFound();
            return View(order);
        }

        public ActionResult MyOrders()
        {
            if (!LoggedIn()) return RedirectToAction("Login", "Account");
            var orders = db.Orders.Where(x => x.UserId == CurrentUserId.Value)
                .OrderByDescending(x => x.OrderDate).ToList();
            return View(orders);
        }

        public ActionResult Details(int id)
        {
            if (!LoggedIn()) return RedirectToAction("Login", "Account");
            var order = db.Orders.Include("Items").FirstOrDefault(x => x.OrderId == id && x.UserId == CurrentUserId.Value);
            if (order == null) return HttpNotFound();
            return View(order);
        }
    }
}
