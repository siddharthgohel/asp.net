using System.Linq;
using System.Web.Mvc;
using FastFoodDelivery.Models;

namespace FastFoodDelivery.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext db = new ApplicationDbContext();

        public ActionResult Register() { return View(); }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Register(User user, string confirmPassword)
        {
            if (user.PasswordHash != confirmPassword)
                ModelState.AddModelError("PasswordHash", "Passwords do not match.");

            if (db.Users.Any(x => x.Email == user.Email))
                ModelState.AddModelError("Email", "Email is already registered.");

            if (!ModelState.IsValid) return View(user);

            user.PasswordHash = SeedData.Hash(user.PasswordHash);
            user.Role = "Customer";
            db.Users.Add(user);
            db.SaveChanges();
            TempData["Success"] = "Registration successful. Please login.";
            return RedirectToAction("Login");
        }

        public ActionResult Login(string returnUrl) {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Login(string email, string password, string returnUrl)
        {
            var hash = SeedData.Hash(password);
            var user = db.Users.FirstOrDefault(x => x.Email == email && x.PasswordHash == hash);
            if (user == null) {
                ViewBag.Message = "Invalid email or password.";
                return View();
            }

            Session["UserId"] = user.UserId;
            Session["UserName"] = user.FullName;
            Session["Role"] = user.Role;

            if (user.Role == "Admin")
                return RedirectToAction("Dashboard", "Admin");
            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);
            return RedirectToAction("Index", "Home");
        }

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Index", "Home");
        }
    }
}
