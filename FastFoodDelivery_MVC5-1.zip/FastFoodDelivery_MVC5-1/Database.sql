CREATE DATABASE FastFoodDeliveryDB;
GO
USE FastFoodDeliveryDB;
GO
CREATE TABLE Categories(
 CategoryId INT IDENTITY(1,1) PRIMARY KEY,
 Name NVARCHAR(80) NOT NULL
);
CREATE TABLE Users(
 UserId INT IDENTITY(1,1) PRIMARY KEY,
 FullName NVARCHAR(100) NOT NULL,
 Email NVARCHAR(150) NOT NULL UNIQUE,
 PasswordHash NVARCHAR(500) NOT NULL,
 Phone NVARCHAR(20),
 Address NVARCHAR(300),
 Role NVARCHAR(20) NOT NULL DEFAULT 'Customer'
);
CREATE TABLE FoodItems(
 FoodItemId INT IDENTITY(1,1) PRIMARY KEY,
 Name NVARCHAR(120) NOT NULL,
 Description NVARCHAR(500),
 Price DECIMAL(10,2) NOT NULL,
 ImageUrl NVARCHAR(500),
 IsAvailable BIT NOT NULL DEFAULT 1,
 CategoryId INT NOT NULL FOREIGN KEY REFERENCES Categories(CategoryId)
);
CREATE TABLE Orders(
 OrderId INT IDENTITY(1,1) PRIMARY KEY,
 UserId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
 OrderDate DATETIME NOT NULL DEFAULT GETDATE(),
 Status NVARCHAR(50) NOT NULL DEFAULT 'Placed',
 DeliveryAddress NVARCHAR(300) NOT NULL,
 TotalAmount DECIMAL(10,2) NOT NULL
);
CREATE TABLE OrderItems(
 OrderItemId INT IDENTITY(1,1) PRIMARY KEY,
 OrderId INT NOT NULL FOREIGN KEY REFERENCES Orders(OrderId),
 FoodItemId INT NOT NULL FOREIGN KEY REFERENCES FoodItems(FoodItemId),
 FoodName NVARCHAR(120) NOT NULL,
 UnitPrice DECIMAL(10,2) NOT NULL,
 Quantity INT NOT NULL,
 LineTotal DECIMAL(10,2) NOT NULL
);
INSERT INTO Categories(Name) VALUES ('Pizza'),('Burger'),('Sides'),('Drinks');
INSERT INTO FoodItems(Name,Description,Price,ImageUrl,IsAvailable,CategoryId) VALUES
('Margherita Pizza','Classic cheese and tomato pizza.',199,'https://images.unsplash.com/photo-1574071318508-1cdbab80d002',1,1),
('Farmhouse Pizza','Loaded with fresh vegetables and cheese.',299,'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38',1,1),
('Classic Burger','Juicy patty, lettuce, tomato and sauce.',149,'https://images.unsplash.com/photo-1568901346375-23c9450c58cd',1,2),
('Cheese Burger','Classic burger with extra melted cheese.',179,'https://images.unsplash.com/photo-1550547660-d9450f859349',1,2),
('French Fries','Crispy golden fries with seasoning.',99,'https://images.unsplash.com/photo-1573080496219-bb080dd4f877',1,3),
('Cold Coffee','Chilled creamy coffee.',119,'https://images.unsplash.com/photo-1461023058943-07fcbe16d735',1,4);
-- Passwords are seeded by the application's SeedData class.
