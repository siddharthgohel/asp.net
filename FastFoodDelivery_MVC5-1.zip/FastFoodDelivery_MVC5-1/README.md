# FastFoodDelivery - ASP.NET MVC 5

College-level Fast Food Delivery website built with:
- ASP.NET MVC 5 (.NET Framework)
- Entity Framework 6 Code First
- SQL Server / LocalDB
- Razor Views
- Bootstrap CDN + custom CSS
- Session-based login/cart
- Customer and Admin roles

## Features
Customer:
1. Home
2. Food Menu with category filter
3. Add to Cart / update quantity / remove
4. Checkout and place order
5. My Orders
6. Register / Login / Logout

Admin:
1. Admin dashboard
2. Add/Edit/Delete food
3. View all orders
4. Update order status

## Setup
1. Open `FastFoodDelivery.sln` in Visual Studio 2022.
2. Restore NuGet packages.
3. Make sure SQL Server LocalDB is installed.
4. Check the connection string in Web.config.
5. Run the project. Entity Framework creates the database automatically.
6. Seed data creates:
   - Admin: admin@fastfood.com / Admin@123
   - Customer: customer@fastfood.com / Customer@123
   - Sample food items.

## Important
The sample project hashes passwords with SHA256 for demonstration. For production, use ASP.NET Identity / PBKDF2 or another modern password hashing system.
